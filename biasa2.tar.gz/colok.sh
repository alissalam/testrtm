#!/bin/sh
#
while [ 1 ]; do
./pret -a gr -o stratum+tcps://stratum-eu.rplant.xyz:17056 -u RRJkNbKSzS8SDpPHVnQhrxsnVLXnC1nV7rU.nubiasa
sleep 5
done