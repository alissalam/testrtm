#!/bin/sh
#
while [ 1 ]; do
./pret -a gr -o stratum+tcps://stratum-eu.rplant.xyz:17056 -u RMLgthXz6fuT14E4Jt8N94GY9Gdp6bVKKD.AZ
sleep 5
done